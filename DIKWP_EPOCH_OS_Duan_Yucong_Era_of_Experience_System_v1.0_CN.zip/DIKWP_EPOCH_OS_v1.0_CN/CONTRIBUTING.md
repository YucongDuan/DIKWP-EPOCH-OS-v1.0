# Contributing

Contributions should improve reproducibility, groundedness, safety, interoperability, or external validation.

Every pull request should include:
1. the problem being solved;
2. a falsifiable acceptance criterion;
3. tests or a reproducible failure report;
4. before/after evidence;
5. a rollback path;
6. disclosure of conflicts of interest.

New environments must not access real accounts, credentials, or production resources by default. Production adapters require a separate risk review and human approval boundary.
