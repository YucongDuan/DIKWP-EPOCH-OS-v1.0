# Roadmap

## 0–30 days

- Freeze ExperienceCell v1 and terminology.
- Convert ten PACT scenarios into interactive environments.
- Publish Linux/macOS/Windows clean-run instructions.
- Complete MESH, ProofLedger, and P-Space adapters.

## 31–60 days

- Obtain two independent reproductions.
- Publish at least three failure reports.
- Run action-substitution, state-intervention, delayed-consequence, and reward-gaming experiments.

## 61–90 days

- Publish EPOCH-Bench v0.1.
- Register and review initial SkillOptions.
- Conduct a non-founder release exercise.
- Select one low-risk Hainan shadow scenario with a responsible operator and exit plan.

## 2027+

- Add open-weight agent adapters.
- Establish federated Experience Commons nodes.
- Build cross-environment transfer matrices.
- Advance only after independent replication and governance closure.
