# Succession

If the founding maintainer is inactive for 180 days, registered non-founder maintainers may create a continuity fork. The fork must preserve provenance, version history, licenses, authorship, known failures, and the exact divergence point. It may not impersonate a natural person or claim untransferred institutional authority.
