# 快速启动

## 1. 本地安装

```bash
cd DIKWP_EPOCH_OS_v1.0_CN
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e .
```

## 2. 运行确定性演示

```bash
dikwp-epoch demo --outdir outputs/demo --episodes 50 --seed 20260718
```

生成：
- `experience_ledger.jsonl`：追加式经验账本；
- `experience_pack.json`：可联邦交换的经验包；
- `summary.json`：训练、门控、技能和质量指标；
- `learning_curve.csv`：各环境学习曲线；
- `world_model.json`：世界模型快照；
- `skills.json`：发现的时间抽象技能。

## 3. 运行测试

```bash
pytest -q
```

## 4. 打开离线驾驶舱

直接打开 `prototype/index.html`。页面无远程脚本、Cookie 或隐藏遥测。

## 5. 关键边界

- 演示环境为合成沙箱，不代表真实系统部署结果；
- 参考学习器用于验证协议链路，不声称复现完整 Oak 架构；
- 高风险动作必须由外部责任主体授权；
- 不记录或要求模型私有思维链，只记录可审计的状态、主张、行动和后果；
- 任何“经验能力”都不等同于现象意识或主观感受证明。
