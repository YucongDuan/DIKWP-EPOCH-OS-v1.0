# Code of Conduct

Participate with evidence, civility, and respect. Criticism of claims and methods is welcome; harassment, identity attacks, fabricated evidence, and suppression of reproducible negative results are not.
