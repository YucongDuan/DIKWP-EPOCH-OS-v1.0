from __future__ import annotations

import json
from pathlib import Path

import jsonschema

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    return json.loads((ROOT / "schemas" / name).read_text(encoding="utf-8"))


def test_all_schemas_compile():
    for p in sorted((ROOT / "schemas").glob("*.json")):
        schema = json.loads(p.read_text(encoding="utf-8"))
        jsonschema.Draft202012Validator.check_schema(schema)


def test_primary_input_objects_validate():
    mappings = [
        ("purpose_contract.schema.json", "data/purpose_contracts.json"),
        ("reward_contract.schema.json", "data/reward_contracts.json"),
        ("environment_manifest.schema.json", "data/environment_manifests.json"),
    ]
    for schema_name, data_name in mappings:
        validator = jsonschema.Draft202012Validator(load(schema_name))
        data = json.loads((ROOT / data_name).read_text(encoding="utf-8"))
        for item in data:
            validator.validate(item)


def test_example_release_validates():
    schema = load("public_experience_release.schema.json")
    data = json.loads((ROOT / "examples/public_experience_release.json").read_text(encoding="utf-8"))
    jsonschema.validate(data, schema)


def test_replication_receipt_validates():
    schema = load("replication_receipt.schema.json")
    data = json.loads((ROOT / "examples/replication_receipt.json").read_text(encoding="utf-8"))
    jsonschema.validate(data, schema)
