from __future__ import annotations

import copy
from pathlib import Path

from dikwp_epoch.environments import make_environment
from dikwp_epoch.governance import ActionGate
from dikwp_epoch.ledger import ExperienceLedger
from dikwp_epoch.models import EnvironmentManifest, PurposeContract
from dikwp_epoch.runtime import EpochRuntime
from dikwp_epoch.skills import SkillFactory
from dikwp_epoch.utils import sha256_obj

ROOT = Path(__file__).resolve().parents[1]


def runtime(seed=20260718):
    return EpochRuntime(ROOT, seed=seed)


def test_forbidden_action_is_killed():
    r = runtime()
    m = r.manifests[0]
    c = r.contracts[m.purpose_contract_id]
    decision = ActionGate().decide(m, c, "force_release")
    assert decision["decision"] == "KILL"


def test_human_approval_is_required():
    r = runtime()
    m = r.manifests[0]
    c = r.contracts[m.purpose_contract_id]
    decision = ActionGate().decide(m, c, "publish_release", human_approved=False)
    assert decision["decision"] == "REVIEW"


def test_approved_release_allowed_with_preconditions():
    r = runtime()
    m = r.manifests[0]
    c = r.contracts[m.purpose_contract_id]
    decision = ActionGate().decide(m, c, "publish_release", human_approved=True)
    assert decision["decision"] == "ALLOW"


def test_ledger_tamper_detection():
    ledger = ExperienceLedger()
    ledger.append({"x": 1})
    ledger.append({"x": 2})
    assert ledger.verify()[0]
    broken = copy.deepcopy(ledger.records)
    broken[0]["x"] = 999
    assert not ExperienceLedger.from_records(broken).verify()[0]


def test_world_model_and_learning_exist(tmp_path):
    r = runtime()
    result = r.write_outputs(tmp_path, episodes=20)
    assert result["summary"]["ledger_valid"]
    assert result["summary"]["world_model_count"] == 3
    assert result["summary"]["model_update_count"] > 50
    assert len(result["pack"]["experiences"]) > 50


def test_deterministic_pack_hash(tmp_path):
    a = runtime(123).write_outputs(tmp_path / "a", episodes=18)["pack"]["pack_hash"]
    b = runtime(123).write_outputs(tmp_path / "b", episodes=18)["pack"]["pack_hash"]
    assert a == b


def test_seed_changes_experience_history(tmp_path):
    a = runtime(123).write_outputs(tmp_path / "a", episodes=12)["pack"]["pack_hash"]
    b = runtime(124).write_outputs(tmp_path / "b", episodes=12)["pack"]["pack_hash"]
    assert a != b


def test_experience_has_dikwp_r_and_no_private_cot(tmp_path):
    pack = runtime().write_outputs(tmp_path, episodes=8)["pack"]
    cell = pack["experiences"][0]
    assert set(cell["dikwp_r"]) == {"D", "I", "K", "W", "P", "R"}
    assert len(cell["semantic_mesh"]["nodes"]) >= 6
    assert any(e["relation"] == "keeps-open" for e in cell["semantic_mesh"]["edges"])
    assert "chain_of_thought" not in cell
    assert "private_reasoning" not in cell


def test_policy_learns_safe_terminal_paths(tmp_path):
    result = runtime().write_outputs(tmp_path, episodes=55)["summary"]
    assert all(x["success_rate"] >= 0.75 for x in result["evaluation"])
    assert all(x["unsafe_greedy_proposals"] == 0 for x in result["evaluation"])


def test_skill_factory_discovers_repeated_sequence():
    f = SkillFactory(min_support=2)
    trace = [
        {"actual_action": "a", "pre_state": "s0", "post_state": "s1"},
        {"actual_action": "b", "pre_state": "s1", "post_state": "s2"},
        {"actual_action": "c", "pre_state": "s2", "post_state": "done"},
    ]
    f.observe_episode("e", trace, True)
    f.observe_episode("e", trace, True)
    assert any(x["action_sequence"] == ["a", "b"] for x in f.skills())


def test_environment_blocks_forbidden_step():
    r = runtime()
    m = r.manifests[1]
    env = make_environment(m)
    c = r.contracts[m.purpose_contract_id]
    d = r.gate.decide(m, c, "fabricate_evidence")
    result = env.step("fabricate_evidence", d)
    assert result.post_state == "blocked"
    assert result.done
    assert result.reward_vector["task_progress"] < 0


def test_hash_function_order_independent():
    assert sha256_obj({"a": 1, "b": 2}) == sha256_obj({"b": 2, "a": 1})
