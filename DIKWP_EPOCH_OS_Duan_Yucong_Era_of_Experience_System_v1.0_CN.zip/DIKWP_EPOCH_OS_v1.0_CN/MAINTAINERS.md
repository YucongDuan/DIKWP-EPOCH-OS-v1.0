# Maintainers

Public release must name at least:
- one specification maintainer;
- one runtime maintainer;
- one independent review lead;
- one environment/adoption lead.

Before these roles are confirmed, this package remains a reference delivery and not an institutional release.
