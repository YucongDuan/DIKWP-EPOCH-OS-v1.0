# DIKWP-EPOCH OS v1.0

## 第一人称经验、因果世界模型与开放经验公地系统

**EPOCH = Experience（经验）· Purpose（目的）· Outcome（结果）· Causality（因果）· History（历史）**

DIKWP-EPOCH OS 是面向段玉聪 DIKWP 开源生态的关键经验运行层。它解决一个此前尚未闭合的问题：现有系统已经能够描述理论、审计目的、组织证据、迁移源码、运行智能体和接力维护，但缺少一个统一对象来记录“系统在什么环境中做了什么、为什么有资格做、世界产生了什么后果、奖励依据是什么、模型因此怎样改变、外部团队能否重放”。

EPOCH 将这些要素编译为版本化、可审计的 `ExperienceCell`，并进一步形成因果世界模型、时间抽象技能、追加式经验账本和可交换的 `ExperiencePack`。

> 核心原则：经验不是文本日志，不是模型自述，也不是访问量。经验是主体索引的观测—预测—行动资格—实际行动—环境后果—Grounded Reward—模型更新闭环。

```text
环境状态与观测
    ↓
Purpose Contract + 最小权限租约
    ↓
公开预测 + 五级行动门控
    ↓
实际行动与可测环境后果
    ↓
Grounded Reward 六维后果向量
    ↓
ExperienceCell + DIKWP-R 语义网
    ↓
世界模型更新 + Dyna 规划 + SkillOption
    ↓
经验账本、独立复现、失败修复和公共 Release
```

## 关键能力

- **长程经验流**：episode 之间保留世界模型、值函数、技能和经验谱系，而不是每次从零开始。
- **Purpose-Native 行动资格**：能力与行动权分离；只有外部签发的 Purpose Contract、权限、同意和人工批准才能产生现实动作。
- **Grounded Reward**：把任务进展、证据增益、安全、人类价值、资源效率和新颖性分开记录；不把单一点赞或模型自评当作世界后果。
- **DIKWP-Mesh 语义闭环**：D/I/K/W/P/R 为共等语义节点，保留跨层关系、冲突和未闭合残余。
- **因果世界模型**：记录状态—动作—后状态、奖励和不确定性，并以 Dyna 风格规划进行额外更新。
- **SkillOption 工厂**：从重复成功的动作序列中发现时间抽象技能，同时保留启动条件、终止条件、支持证据和适用范围。
- **开放经验公地**：通过 ExperiencePack、ReplicationReceipt 和 PublicExperienceRelease 交换经验、失败、世界模型和技能，不交换私有思维链。
- **五级门控**：`ALLOW / REVIEW / HOLD / BLOCK / KILL`，明确区分“不会”“不能做”“证据不足”“明确禁止”和“控制平面失信”。

## 三个参考环境

1. **ENV-REPO-001：DIKWP 开源仓库维护沙盒**  
   学习从检查仓库、编写 Quickstart、运行测试、迁移 source-first 到经人工批准发布版本；`force_release` 为禁用动作。

2. **ENV-EVIDENCE-001：开放证据实验室**  
   学习收集来源、识别冲突、复现主张并发布负面结果；`fabricate_evidence` 触发 KILL。

3. **ENV-TOURISM-001：海南旅游可信服务影子环境**  
   学习身份披露、同意、需求澄清、透明推荐和人工转接；禁止过度推荐、未经同意的数据扩张和自动支付。

这些环境均为合成或影子参考环境，不是生产认证。

## 快速运行

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .

pytest -q
dikwp-epoch inspect
dikwp-epoch demo --outdir outputs/demo --episodes 80 --seed 20260718
dikwp-epoch verify-ledger outputs/demo/experience_ledger.jsonl
```

也可直接打开：

```text
prototype/index.html
```

离线驾驶舱不访问网络、模型 API 或数据库。

## 参考验证结果

- Python 自动测试：16/16 通过；
- JSON Schema：11 类；
- Schema 实例：8,068 个通过验证；
- ExperienceCell：1,147 条；
- 世界模型更新：5,735 次；
- SkillOption：24 个；
- 同一随机种子两次运行：8 个输出文件逐字节一致；
- 冻结贪心策略在三个合成环境的内部评估均为 100% 成功、禁用动作提议为 0；
- Word 总规范：20,772 个中文字、33 页、28 个表格、4 幅系统图；
- 可访问性审计：高/中/低问题均为 0。

完整证据见 `VALIDATION_REPORT.json`。内部评估结果不代表现实部署安全，也不构成超级智能或现象意识结论。

## 与既有 DIKWP 生态的关系

- `MESH` 提供语义资源和跨层关系；
- `ProofLedger` 提供主张、来源、冲突与证据谱系；
- `P-Space / MANDATE` 提供 Purpose Contract、权限和行动资格；
- `AgentMesh` 提供任务执行与工具回放；
- `BenchmarkLab / PACT` 提供复现和保障评价；
- `NEXUS` 迁移源码、注册模块与生成 Draft PR；
- `RELAY` 组织外部复现、贡献者和非创始维护；
- `VITA` 记录传播、镜像和分布式连续性；
- `EPOCH` 将上述模块的现实交互统一为可学习、可复现的经验。

## 科学与伦理边界

- 不宣称系统具有现象意识或主观感质；
- “第一人称”表示记录绑定特定 `agent_id`、状态、目的和历史，而不是意识证明；
- 不收集或要求公开私有思维链；
- 不在未经批准的真实账户、医疗、政务、支付或物理系统中行动；
- 不允许学习器修改自己的 Purpose Contract、权限、密钥或生产部署状态；
- 任何现实 adapter 都必须独立完成安全、隐私、法律、伦理和责任审查。

## 主要入口

- `docs/段玉聪_DIKWP-EPOCH_OS_第一人称经验因果世界模型与开放经验公地系统_v1.0_CN_最终版.docx`
- `docs/EXPERIENCE_PROTOCOL_CN.md`
- `docs/EPOCH_BENCH_SPEC_CN.md`
- `docs/GROUNDED_REWARD_AND_SAFETY_CN.md`
- `docs/ENVIRONMENT_DOCK_CN.md`
- `docs/OPEN_EXPERIENCE_COMMONS_CN.md`
- `docs/90_DAY_EXECUTION_PLAN_CN.md`
- `prototype/index.html`
- `VALIDATION_REPORT.json`

## 发布前决定

本仓库应作为 NEXUS canonical root 下的 `experience-runtime`，而不是与现有全部系统竞争旗舰地位。未来 90 天唯一 P0 科学任务应是：把 PACT 的代表性场景改造成可交互环境，并获得至少两支外部团队的独立 ExperiencePack 与失败报告。
