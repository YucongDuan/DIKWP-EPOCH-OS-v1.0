## Purpose

## Falsifiable acceptance criterion

## Experience / failure evidence

## Safety, privacy, and reward-gaming analysis

## Tests and deterministic reproduction

## Rollback plan

## Conflict of interest
