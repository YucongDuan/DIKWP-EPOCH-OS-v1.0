# Governance

DIKWP-EPOCH uses a four-role governance model: specification maintainer, environment maintainer, independent reproducer, and field-responsible adopter. No single role may approve a high-risk production promotion alone.

Changes to the shared experience schema, reward contract, or safety gate require:
- public issue;
- reference implementation;
- regression suite;
- impact analysis;
- at least one non-author review;
- versioned release notes.

The project preserves negative results and superseded models. History may be corrected by append-only revision events, not silently rewritten.
