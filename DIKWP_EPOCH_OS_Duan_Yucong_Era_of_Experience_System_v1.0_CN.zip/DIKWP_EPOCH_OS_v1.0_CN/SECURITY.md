# Security Policy

The reference system is offline-first and synthetic by default. Do not put credentials, private personal data, production tokens, or regulated data into experience packs.

Report security issues privately before public disclosure. Critical classes include:
- path traversal or unsafe archive handling;
- ledger tampering;
- reward manipulation;
- action-lease bypass;
- unapproved production promotion;
- prompt injection crossing the environment boundary;
- personally identifying telemetry.
