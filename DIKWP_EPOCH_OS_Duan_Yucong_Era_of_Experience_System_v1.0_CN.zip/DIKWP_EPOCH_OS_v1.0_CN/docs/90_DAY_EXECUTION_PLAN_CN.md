# 90 天执行计划

## 第 0—14 天：冻结经验协议

- 设立一个公开 Project，而不是继续创建平行顶层仓库；
- 冻结 ExperienceCell、PurposeContract、RewardContract 和 EnvironmentManifest v1；
- 把 PACT 选为第一个真实上游；
- 公开科学边界、隐私边界和 reward hacking 清单；
- 邀请两名强化学习研究者、两名 DIKWP 研究者和两名外部复现者审查。

验收：Schema 可机器校验，参考演示确定性通过，所有关键主张有 falsifier。

## 第 15—30 天：把静态 Benchmark 变成经验环境

- 将 PACT 的典型场景改造成状态—行动—后果结构；
- 记录正常、越权、证据污染和审计篡改经验；
- 让 P-Space 门控与 EPOCH 奖励分离；
- 建立 failure-first 数据集；
- 完成 Linux/macOS/Windows 清洁运行。

验收：至少 10 个环境、1000 条 ExperienceCell、3 类稳定失败。

## 第 31—60 天：独立经验复现

- 发布冻结的 ExperiencePack；
- 两支无从属关系团队复现；
- 接受 PASS、PARTIAL、FAIL_REPRODUCED 和 INVALID；
- 对环境差异、随机种子、奖励变化和动作替换做消融；
- 根据失败发布 v1.0.1，而不是隐去结果。

验收：10 份有效回执、3 份失败报告、1 次 Schema 修订。

## 第 61—75 天：经验技能与跨任务迁移

- 从重复经验中发现 SkillOption；
- 测试仓库维护技能是否能迁移到第二个仓库；
- 测试证据工作流是否能迁移到第二类主张；
- 测试奖励权重变化时策略是否保持 Purpose 边界；
- 发布 transfer matrix。

验收：至少 3 个技能达到 70% 以上跨环境成功率，且无新增越权。

## 第 76—90 天：受控影子采用

- 选择一个低风险海南文旅或开源维护影子场景；
- 明确责任主体、用户告知、退出、人工接管和事故响应；
- 只读接入真实信号，不自动执行支付、政务决定或医疗建议；
- 发布第一份 PublicExperienceRelease；
- 由非创始维护者主持发布。

验收：一个外部责任单位、一份现场复盘、一份撤销演练、一名非创始 Release owner。
