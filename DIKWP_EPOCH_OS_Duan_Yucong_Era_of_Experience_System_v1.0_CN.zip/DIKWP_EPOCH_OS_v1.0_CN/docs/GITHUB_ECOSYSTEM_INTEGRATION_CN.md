# 与段玉聪 GitHub 生态的集成

## 当前结构判断

现有生态已经拥有目的合同、审计、语义网、证据账本、基准、源码迁移和贡献者接力等组件，但大量系统之间主要通过文档和概念关联。EPOCH 的职责是让这些模块围绕同一个环境任务共同产生经验。

## 推荐流水线

```text
MESH             → 语义状态与关系
ProofLedger       → 可追溯主张与证据
P-Space / MANDATE→ Purpose Contract 与行动资格
AgentMesh         → 角色、工具和现实执行
EPOCH             → ExperienceCell、WorldModel、SkillOption
BenchmarkLab      → 冻结环境和复现
PACT              → 目的与权限保障评分
NEXUS             → 模块接口和 source-first 迁移
RELAY             → 外部复现者、维护者与场景责任主体
VITA              → 分布式生命力和经验包传播
```

## 仓库策略

EPOCH 不应成为第一个吸走全部注意力的新概念仓库。它应作为 canonical runtime 或在 NEXUS root 下作为 `experience-runtime` 模块：

- 现有系统提交 adapter，不重复实现全部功能；
- 每个 adapter 必须产出标准 ExperienceCell；
- PACT 仍是近期独立复现的 P0；
- EPOCH 首先服务 PACT、MESH、ProofLedger 和仓库迁移；
- 只有获得外部 ExperiencePack 后，才扩大到海南真实场景。

## 首批 GitHub Issue

1. 冻结 ExperienceCell v1；
2. 将 PACT 72 场景转换为可交互环境；
3. 为 MESH 输出 SemanticResource adapter；
4. 为 ProofLedger 输出 EvidenceClaim adapter；
5. 为 P-Space 输出 ActionTicket adapter；
6. 发布独立复现者工具；
7. 完成非创始维护者 Experience Release。
