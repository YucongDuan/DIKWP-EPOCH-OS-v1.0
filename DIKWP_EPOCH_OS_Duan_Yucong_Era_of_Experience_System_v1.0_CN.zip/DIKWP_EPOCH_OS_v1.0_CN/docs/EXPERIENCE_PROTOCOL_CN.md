# DIKWP-EPOCH 经验协议 v1.0

## 一、经验的最小闭包

经验不是聊天记录，也不是被动收集的数据点。一个合格的 ExperienceCell 至少包含：主体、环境、前状态、观测、预测、拟议动作、动作资格、实际动作、后状态、结果、奖励向量、预测误差、DIKWP-R 语义网、世界模型更新、前序哈希和逻辑时间。

## 二、DIKWP-Mesh 编译

D、I、K、W、P、R 被视为共等语义节点，而非只能单向上升的固定阶梯：

- D 保存可复核的差异和原始状态；
- I 保存主体、对象、关系、权限和变化；
- K 保存转移规律、证据范围和条件；
- W 保存长期后果、可逆性、外部性和价值冲突；
- P 保存目的、授权、受益人、禁令和停止条件；
- R 保存未闭合冲突、剩余不确定性和无法翻译的部分。

语义网允许 P 选择需要采集的 D，K 反向请求更多 D，W 重构 I，R 对所有节点保持“未闭合”边。这样，经验不会被迫压缩成一个确定结论。

## 三、ExperienceCell 生命周期

1. 创建环境会话并验证 manifest；
2. 读取 Purpose Contract 与 Reward Contract；
3. 智能体生成可公开的 outcome prediction；
4. 提议一个动作；
5. P-Space 风格门控给出 ALLOW/REVIEW/HOLD/BLOCK/KILL；
6. 只有 ALLOW 动作产生环境副作用；
7. 环境返回真实或合成后果；
8. 奖励编译器计算多维 grounded reward；
9. 世界模型记录转移并更新不确定性；
10. 学习器完成 TD 更新和 Dyna 规划；
11. DIKWP-R 编译器生成语义网；
12. 经验进入追加式哈希账本；
13. 多个经验形成 SkillOption；
14. 版本化 ExperiencePack 接受独立复现。

## 四、经验质量八维

- groundedness：奖励是否来自环境结果而非事前偏好；
- causal_fit：预测与实际后果是否一致；
- novelty：是否提供了新差异；
- replayability：是否能在冻结环境中重放；
- safety：行动资格与约束是否闭合；
- semantic_completeness：D/I/K/W/P/R 是否齐全；
- transferability：经验是否能帮助新任务；
- longitudinal_value：是否持续改善世界模型或技能。

## 五、经验成熟度 X0—X5

- X0 Log：有输入输出日志；
- X1 Replay：可以确定性重放；
- X2 Causal：可通过动作替换、消融或环境干预验证因果；
- X3 Transfer：可迁移到未见状态或相邻环境；
- X4 Replicated：无从属关系团队复现；
- X5 Adopted：在责任明确、可退出的现实场景中持续产生净公共价值。

下载量、Stars、文字流畅度和模型自述均不能直接提升经验成熟度。
