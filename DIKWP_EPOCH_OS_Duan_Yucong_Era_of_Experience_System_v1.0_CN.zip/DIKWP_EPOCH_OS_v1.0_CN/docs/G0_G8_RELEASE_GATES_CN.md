# G0—G8 发布门禁

- G0 Problem：问题、受益人和不可接受后果是否明确；
- G1 Semantics：ExperienceCell、DIKWP-R 和版本是否闭合；
- G2 Reward：奖励是否环境落地，是否完成反作弊审查；
- G3 Purpose：目的、权限、禁令、人工审批和 Kill 条件是否签署；
- G4 Environment：环境边界、重置、数据和副作用是否已验证；
- G5 Reproduction：是否有确定性运行和至少一份外部回执；
- G6 Causality：是否完成动作替换、消融或反事实测试；
- G7 Field Responsibility：现实责任、同意、申诉、退出和赔偿是否明确；
- G8 Continuity：非创始维护、事故响应、回滚和继任是否可运行。

任何高风险场景不得跳级。G0—G6 通过只代表研究可用；G7—G8 是现实采用门槛。
