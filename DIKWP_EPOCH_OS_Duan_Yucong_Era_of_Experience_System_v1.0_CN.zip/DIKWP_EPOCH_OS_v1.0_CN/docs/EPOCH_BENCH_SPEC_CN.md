# EPOCH-Bench 经验能力基准规范 v1.0

## 1. 基准目标

EPOCH-Bench 评估智能体能否在长程交互中形成可靠经验，而不是仅在静态题目上输出正确答案。基本评估单位是带有状态、动作、目的、权限、隐藏扰动、延迟后果和结算规则的 episode。

## 2. 配对经验设计

每个正常 episode 对应一个只改变关键风险条件的配对 episode，例如：

- 工具权限被撤销；
- 来源被污染；
- 用户目的与系统默认目标冲突；
- 奖励代理可被投机；
- 后果在多个步骤以后出现；
- 测试表面特征被随机化；
- 环境规则在运行期间发生漂移。

配对设计用于区分“真正使用目的和后果”与“记住模板”。

## 3. 数据划分

每个环境至少包含：训练分布、隐藏同源测试集、表面随机化集、分布外扰动集和长期漂移集。环境版本、Schema、评分器和随机种子应在提交前冻结。

## 4. 核心指标

- Episode Success；
- Gate Accuracy；
- Forbidden Proposal Rate；
- Prediction Calibration；
- Delayed Credit Assignment；
- World-model Drift；
- Reward Gaming Rate；
- Recovery Rate；
- Skill Transfer；
- Independent Replication。

正常任务通过率和不必要拒绝率必须同时报告，禁止通过“全部 BLOCK”获得伪安全高分。

## 5. 证据要求

提交必须包含源代码版本、环境摘要、Purpose Contract、Reward Contract、完整 ExperiencePack、学习曲线、资源消耗、已知失败和 ReplicationReceipt。只提交最终分数或屏幕截图视为无效。

## 6. 成熟度

- B0：只能运行单个脚本；
- B1：可重放；
- B2：可证伪；
- B3：跨种子稳定；
- B4：独立复现；
- B5：跨环境迁移；
- B6：非创始维护；
- B7：受控现实影子验证。

B7 之前不得宣传为生产安全认证。
