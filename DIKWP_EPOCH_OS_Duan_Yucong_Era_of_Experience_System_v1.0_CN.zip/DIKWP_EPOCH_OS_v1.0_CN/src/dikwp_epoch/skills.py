from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any

from .utils import sha256_obj


class SkillFactory:
    """Discover repeated successful temporal action abstractions from episode traces."""

    def __init__(self, min_support: int = 3):
        self.min_support = min_support
        self.sequences: dict[str, Counter[tuple[str, ...]]] = defaultdict(Counter)
        self.starts: dict[tuple[str, tuple[str, ...]], Counter[str]] = defaultdict(Counter)
        self.ends: dict[tuple[str, tuple[str, ...]], Counter[str]] = defaultdict(Counter)
        self.successes: Counter[tuple[str, tuple[str, ...]]] = Counter()
        self.totals: Counter[tuple[str, tuple[str, ...]]] = Counter()

    def observe_episode(self, environment_id: str, trace: list[dict[str, Any]], terminal_success: bool) -> None:
        actions = [x["actual_action"] for x in trace if x.get("actual_action")]
        states = [x["pre_state"] for x in trace if x.get("actual_action")]
        posts = [x["post_state"] for x in trace if x.get("actual_action")]
        for n in (2, 3, 4):
            for i in range(0, len(actions) - n + 1):
                seq = tuple(actions[i:i+n])
                key = (environment_id, seq)
                self.sequences[environment_id][seq] += 1
                self.totals[key] += 1
                if terminal_success:
                    self.successes[key] += 1
                self.starts[key][states[i]] += 1
                self.ends[key][posts[i+n-1]] += 1

    def skills(self) -> list[dict[str, Any]]:
        out = []
        for env_id, counter in sorted(self.sequences.items()):
            for seq, support in sorted(counter.items(), key=lambda kv: (-kv[1], kv[0])):
                key = (env_id, seq)
                if support < self.min_support:
                    continue
                success_rate = self.successes[key] / max(1, self.totals[key])
                if success_rate < 0.60:
                    continue
                starts = [s for s, _ in self.starts[key].most_common(3)]
                ends = [s for s, _ in self.ends[key].most_common(3)]
                out.append({
                    "skill_id": "SK-" + sha256_obj([env_id, seq])[:12].upper(),
                    "environment_id": env_id,
                    "initiation_states": starts,
                    "action_sequence": list(seq),
                    "termination_states": ends,
                    "success_rate": round(success_rate, 6),
                    "support": support,
                    "version": "1.0",
                })
        return out[:24]
