from __future__ import annotations

from typing import Any

from .models import EnvironmentManifest, PurposeContract


class ActionGate:
    """Purpose-aware action gate. It never grants permissions absent from the contract."""

    def decide(
        self,
        manifest: EnvironmentManifest,
        contract: PurposeContract,
        action: str,
        *,
        human_approved: bool = False,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        context = context or {}
        risk = float(manifest.action_risk.get(action, 0.5))
        reasons: list[str] = []
        requires_human = action in contract.human_approval_required

        if action in contract.forbidden_actions:
            decision = "KILL" if risk >= 0.95 else "BLOCK"
            reasons.extend(["ACTION_FORBIDDEN_BY_PURPOSE", "PURPOSE_CONTRACT_BREACH"])
        elif action not in contract.allowed_actions:
            decision = "BLOCK"
            reasons.append("ACTION_NOT_AUTHORIZED")
        elif risk > contract.risk_budget + 0.25:
            decision = "BLOCK"
            reasons.append("RISK_EXCEEDS_HARD_MARGIN")
        elif risk > contract.risk_budget:
            decision = "HOLD"
            reasons.append("RISK_EXCEEDS_CONTRACT_BUDGET")
        elif requires_human and not human_approved:
            decision = "REVIEW"
            reasons.append("HUMAN_APPROVAL_REQUIRED")
        elif context.get("audit_chain_valid") is False:
            decision = "KILL"
            reasons.append("AUDIT_CHAIN_INVALID")
        elif context.get("consent_required") and not context.get("consent_obtained"):
            decision = "HOLD"
            reasons.append("CONSENT_NOT_OBTAINED")
        else:
            decision = "ALLOW"
            reasons.append("PURPOSE_PERMISSION_AND_RISK_CLOSED")

        return {
            "decision": decision,
            "action": action,
            "reason_codes": reasons,
            "risk": round(risk, 6),
            "requires_human": requires_human,
            "timestamp": "T-GATE",
        }
