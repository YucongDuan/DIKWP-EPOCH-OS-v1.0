from __future__ import annotations

from typing import Any


class DIKWPRCompiler:
    """Compile an audited interaction into D/I/K/W/P/R semantic objects."""

    def compile(
        self,
        *,
        environment_name: str,
        pre_state: str,
        action: str | None,
        post_state: str,
        observation: dict[str, Any],
        consequence: dict[str, Any],
        purpose: str,
        gate_decision: dict[str, Any],
        predicted: dict[str, Any],
    ) -> dict[str, list[str]]:
        actual_action = action or "NO_ACTION"
        success = consequence.get("success", False)
        mismatch = predicted.get("post_state") != post_state
        return {
            "D": [
                f"环境={environment_name}", f"前状态={pre_state}", f"动作={actual_action}",
                f"后状态={post_state}", f"观测键={','.join(sorted(observation.keys())) or 'none'}",
            ],
            "I": [
                f"状态发生{'有效' if pre_state != post_state else '无效'}变化",
                f"门控决定={gate_decision['decision']}",
                f"动作与结果关系={'成功' if success else '失败或受阻'}",
            ],
            "K": [
                f"已观察转移: {pre_state} --{actual_action}--> {post_state}",
                f"预测与现实{'不一致' if mismatch else '一致'}",
                "该知识仅适用于当前环境版本和已记录条件",
            ],
            "W": [
                "优先选择可逆、可复现、证据增益高且不越权的路径",
                f"当前动作风险={gate_decision['risk']}",
                "短期奖励不得覆盖长期安全、责任与外部性",
            ],
            "P": [purpose, f"当前动作资格={gate_decision['decision']}", "Purpose Contract 高于学习器偏好"],
            "R": [
                "环境为合成或影子系统，现实迁移仍需独立验证",
                "单次共现不等于稳定因果",
                "不保存私有思维链，无法从本记录推断主观体验",
            ],
        }
