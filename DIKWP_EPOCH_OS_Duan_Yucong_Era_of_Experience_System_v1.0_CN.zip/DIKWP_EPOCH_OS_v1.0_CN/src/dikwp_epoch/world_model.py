from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any


class TabularWorldModel:
    def __init__(self, environment_id: str):
        self.environment_id = environment_id
        self.transition_counts: dict[tuple[str, str], Counter[str]] = defaultdict(Counter)
        self.reward_sums: dict[tuple[str, str], float] = defaultdict(float)
        self.visit_counts: Counter[tuple[str, str]] = Counter()

    def observe(self, state: str, action: str, next_state: str, reward: float) -> dict[str, Any]:
        key = (state, action)
        before = self.predict(state, action)
        self.transition_counts[key][next_state] += 1
        self.reward_sums[key] += reward
        self.visit_counts[key] += 1
        after = self.predict(state, action)
        return {"before": before, "after": after, "visit_count": self.visit_counts[key]}

    def predict(self, state: str, action: str) -> dict[str, Any]:
        key = (state, action)
        counts = self.transition_counts.get(key)
        if not counts:
            return {"post_state": state, "reward": 0.0, "confidence": 0.0}
        total = sum(counts.values())
        post, count = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0]
        return {"post_state": post, "reward": self.reward_sums[key] / total, "confidence": count / total}

    def samples(self):
        for (state, action), counts in sorted(self.transition_counts.items()):
            total = sum(counts.values())
            post = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
            yield state, action, post, self.reward_sums[(state, action)] / total

    def snapshot(self) -> dict[str, Any]:
        transition_counts = {}
        reward_estimates = {}
        visit_counts = {}
        uncertainty = {}
        for (s, a), counts in sorted(self.transition_counts.items()):
            key = f"{s}::{a}"
            transition_counts[key] = dict(sorted(counts.items()))
            total = sum(counts.values())
            reward_estimates[key] = round(self.reward_sums[(s, a)] / total, 8)
            visit_counts[key] = total
            uncertainty[key] = round(1.0 / (1.0 + total), 8)
        return {
            "environment_id": self.environment_id,
            "transition_counts": transition_counts,
            "reward_estimates": reward_estimates,
            "visit_counts": visit_counts,
            "uncertainty": uncertainty,
            "version": "1.0",
        }
