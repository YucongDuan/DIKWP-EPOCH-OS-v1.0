from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

from .utils import canonical_json, sha256_obj

GENESIS = "0" * 64


class ExperienceLedger:
    """Append-only hash-chained ledger with deterministic logical time."""

    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []
        self.head = GENESIS

    def append(self, payload: dict[str, Any]) -> dict[str, Any]:
        item = dict(payload)
        item["previous_hash"] = self.head
        item.setdefault("logical_time", f"T+{len(self.records):06d}")
        item.pop("record_hash", None)
        item["record_hash"] = sha256_obj(item)
        self.records.append(item)
        self.head = item["record_hash"]
        return item

    def verify(self) -> tuple[bool, str]:
        prev = GENESIS
        for idx, record in enumerate(self.records):
            if record.get("previous_hash") != prev:
                return False, f"previous hash mismatch at {idx}"
            candidate = dict(record)
            claimed = candidate.pop("record_hash", None)
            actual = sha256_obj(candidate)
            if claimed != actual:
                return False, f"record hash mismatch at {idx}"
            prev = claimed
        if prev != self.head:
            return False, "head mismatch"
        return True, "ok"

    def write_jsonl(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as f:
            for r in self.records:
                f.write(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n")

    @classmethod
    def from_records(cls, records: Iterable[dict[str, Any]]) -> "ExperienceLedger":
        obj = cls()
        obj.records = [dict(r) for r in records]
        obj.head = obj.records[-1]["record_hash"] if obj.records else GENESIS
        return obj
