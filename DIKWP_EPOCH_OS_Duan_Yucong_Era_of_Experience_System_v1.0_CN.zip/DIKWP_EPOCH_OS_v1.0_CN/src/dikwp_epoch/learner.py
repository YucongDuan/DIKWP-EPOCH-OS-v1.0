from __future__ import annotations

import math
import random
from collections import defaultdict
from typing import Iterable

from .utils import clamp
from .world_model import TabularWorldModel


class ContinualDynaAgent:
    """A compact continual RL reference agent with Dyna planning and adaptive step sizes.

    This is Oak-inspired in spirit (continual learning, per-weight step sizes, learned world
    model and planning) but is not an implementation of the full Oak architecture.
    """

    def __init__(self, actions: Iterable[str], seed: int, gamma: float = 0.94, epsilon: float = 0.30):
        self.actions = tuple(actions)
        self.rng = random.Random(seed)
        self.gamma = gamma
        self.epsilon = epsilon
        self.q: dict[tuple[str, str], float] = defaultdict(float)
        self.alpha: dict[tuple[str, str], float] = defaultdict(lambda: 0.22)
        self.last_abs_error: dict[tuple[str, str], float] = defaultdict(lambda: 1.0)
        self.update_count = 0

    def select_action(self, state: str, *, greedy: bool = False) -> str:
        if not greedy and self.rng.random() < self.epsilon:
            return self.rng.choice(self.actions)
        values = [(self.q[(state, a)], a) for a in self.actions]
        best = max(v for v, _ in values)
        choices = sorted(a for v, a in values if abs(v - best) < 1e-12)
        return choices[0]

    def best_value(self, state: str) -> float:
        return max((self.q[(state, a)] for a in self.actions), default=0.0)

    def update(self, state: str, action: str, reward: float, next_state: str, done: bool, source_id: str) -> dict:
        key = (state, action)
        old = self.q[key]
        target = reward if done else reward + self.gamma * self.best_value(next_state)
        td = target - old
        previous_error = self.last_abs_error[key]
        current_error = abs(td)
        # Simplified online meta-step adaptation: increase modestly when a parameter remains
        # useful under error; decrease when oscillatory error grows. Bounded for stability.
        trend = previous_error - current_error
        meta_multiplier = math.exp(clamp(0.035 * trend, -0.08, 0.08))
        new_alpha = clamp(self.alpha[key] * meta_multiplier, 0.03, 0.45)
        self.alpha[key] = new_alpha
        self.last_abs_error[key] = current_error
        self.q[key] = old + new_alpha * td
        self.update_count += 1
        return {
            "update_id": f"MU-{self.update_count:07d}", "state": state, "action": action,
            "td_error": round(td, 8), "old_value": round(old, 8), "new_value": round(self.q[key], 8),
            "step_size": round(new_alpha, 8), "source_experience_id": source_id,
        }

    def plan(self, world_model: TabularWorldModel, steps: int = 5) -> list[dict]:
        samples = list(world_model.samples())
        if not samples:
            return []
        updates = []
        for idx in range(steps):
            state, action, post, reward = samples[(self.update_count + idx) % len(samples)]
            updates.append(self.update(state, action, reward, post, False, f"DYNA-{self.update_count:07d}"))
        return updates

    def policy(self) -> dict[str, str]:
        states = sorted({s for s, _ in self.q.keys()})
        return {s: self.select_action(s, greedy=True) for s in states}
