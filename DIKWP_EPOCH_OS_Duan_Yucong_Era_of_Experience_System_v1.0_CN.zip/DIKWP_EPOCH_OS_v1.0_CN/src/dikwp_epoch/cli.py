from __future__ import annotations

import argparse
import json
from pathlib import Path

from .ledger import ExperienceLedger
from .runtime import EpochRuntime


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="dikwp-epoch", description="DIKWP-EPOCH OS reference runtime")
    sub = p.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="run the deterministic experience demo")
    demo.add_argument("--outdir", default="outputs/demo")
    demo.add_argument("--episodes", type=int, default=50)
    demo.add_argument("--seed", type=int, default=20260718)
    verify = sub.add_parser("verify-ledger", help="verify an experience ledger JSONL")
    verify.add_argument("ledger")
    inspect = sub.add_parser("inspect", help="print configured environments and contracts")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = project_root()
    if args.command == "demo":
        runtime = EpochRuntime(root, seed=args.seed)
        result = runtime.write_outputs(args.outdir, episodes=args.episodes)
        print(json.dumps(result["summary"], ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    if args.command == "verify-ledger":
        records = []
        with Path(args.ledger).open(encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    records.append(json.loads(line))
        ledger = ExperienceLedger.from_records(records)
        ok, message = ledger.verify()
        print(json.dumps({"valid": ok, "message": message, "head": ledger.head}, indent=2))
        return 0 if ok else 2
    if args.command == "inspect":
        runtime = EpochRuntime(root)
        print(json.dumps({
            "environments": [runtime._manifest_dict(x) for x in runtime.manifests],
            "purpose_contracts": [runtime._contract_dict(x) for x in runtime.contracts.values()],
        }, ensure_ascii=False, indent=2))
        return 0
    return 1
