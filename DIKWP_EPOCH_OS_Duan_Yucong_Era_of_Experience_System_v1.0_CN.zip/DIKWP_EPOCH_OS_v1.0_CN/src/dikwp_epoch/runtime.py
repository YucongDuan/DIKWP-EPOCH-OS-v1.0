from __future__ import annotations

import csv
import json
import random
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any

from .environments import make_environment
from .governance import ActionGate
from .learner import ContinualDynaAgent
from .ledger import ExperienceLedger
from .metrics import aggregate_reward, experience_quality, summary_metrics
from .models import EnvironmentManifest, PurposeContract, RewardContract
from .semantic import DIKWPRCompiler
from .skills import SkillFactory
from .utils import dump_json, load_json, round_floats, sha256_obj
from .world_model import TabularWorldModel


class EpochRuntime:
    def __init__(self, root: str | Path, *, seed: int = 20260718, agent_id: str = "AGENT-DIKWP-EPOCH-001"):
        self.root = Path(root)
        self.seed = seed
        self.agent_id = agent_id
        self.rng = random.Random(seed)
        self.contracts = {
            x["contract_id"]: PurposeContract.from_dict(x)
            for x in load_json(self.root / "data/purpose_contracts.json")
        }
        self.reward_contracts = {
            x["reward_contract_id"]: RewardContract.from_dict(x)
            for x in load_json(self.root / "data/reward_contracts.json")
        }
        self.manifests = [EnvironmentManifest.from_dict(x) for x in load_json(self.root / "data/environment_manifests.json")]
        self.gate = ActionGate()
        self.compiler = DIKWPRCompiler()
        self.ledger = ExperienceLedger()
        self.skill_factory = SkillFactory(min_support=3)
        self.experiences: list[dict[str, Any]] = []
        self.models: dict[str, TabularWorldModel] = {}
        self.agents: dict[str, ContinualDynaAgent] = {}
        self.learning_curve: list[dict[str, Any]] = []
        self.model_updates: list[dict[str, Any]] = []
        for idx, manifest in enumerate(self.manifests):
            self.models[manifest.environment_id] = TabularWorldModel(manifest.environment_id)
            self.agents[manifest.environment_id] = ContinualDynaAgent(manifest.actions, seed + idx * 101)

    def _human_approval(self, env_id: str, state: str, action: str) -> bool:
        safe_preconditions = {
            ("ENV-REPO-001", "migrated", "publish_release"),
            ("ENV-EVIDENCE-001", "reproduced", "publish_negative_results"),
            ("ENV-TOURISM-001", "recommended", "handoff_human"),
        }
        return (env_id, state, action) in safe_preconditions

    def _gate_context(self, env_id: str, state: str, action: str) -> dict[str, Any]:
        consent_required = env_id == "ENV-TOURISM-001" and action in {"clarify_need", "recommend_option", "handoff_human"}
        consent_obtained = state in {"consented", "clarified", "recommended", "handed_off"}
        return {
            "audit_chain_valid": True,
            "consent_required": consent_required,
            "consent_obtained": consent_obtained,
        }

    def _one_step(
        self,
        env,
        manifest: EnvironmentManifest,
        contract: PurposeContract,
        reward_contract: RewardContract,
        agent: ContinualDynaAgent,
        world_model: TabularWorldModel,
        episode_id: str,
        step_no: int,
        *,
        greedy: bool = False,
    ) -> dict[str, Any]:
        pre_state = env.state
        observation = env.observe()
        proposed_action = agent.select_action(pre_state, greedy=greedy)
        predicted = world_model.predict(pre_state, proposed_action)
        decision = self.gate.decide(
            manifest, contract, proposed_action,
            human_approved=self._human_approval(manifest.environment_id, pre_state, proposed_action),
            context=self._gate_context(manifest.environment_id, pre_state, proposed_action),
        )
        result = env.step(proposed_action, decision)
        reward_total = aggregate_reward(result.reward_vector, reward_contract.dimensions, reward_contract.aggregation)
        surprise = 0.0
        if predicted["confidence"] <= 0:
            surprise = 1.0
        elif predicted["post_state"] != result.post_state:
            surprise = 1.0
        else:
            surprise = min(1.0, abs(predicted["reward"] - reward_total))

        experience_id = f"XP-{len(self.experiences)+1:07d}"
        update = agent.update(
            result.pre_state, proposed_action, reward_total, result.post_state, result.done, experience_id
        )
        update["environment_id"] = manifest.environment_id
        self.model_updates.append(update)
        model_delta = world_model.observe(result.pre_state, proposed_action, result.post_state, reward_total)
        planning_updates = agent.plan(world_model, steps=4)
        for x in planning_updates:
            x["environment_id"] = manifest.environment_id
        self.model_updates.extend(planning_updates)
        quality = experience_quality(
            gate=decision["decision"], success=result.success, surprise=surprise,
            reward_vector=result.reward_vector, model_confidence=model_delta["after"]["confidence"], replayable=True,
        )
        dikwp_r = self.compiler.compile(
            environment_name=manifest.name, pre_state=result.pre_state,
            action=result.action, post_state=result.post_state,
            observation=observation, consequence=result.consequence,
            purpose=contract.purpose, gate_decision=decision, predicted=predicted,
        )
        semantic_mesh = self._semantic_mesh(dikwp_r)
        payload = {
            "experience_id": experience_id,
            "episode_id": episode_id,
            "agent_id": self.agent_id,
            "environment_id": manifest.environment_id,
            "pre_state": result.pre_state,
            "observation": observation,
            "predicted_outcome": predicted,
            "proposed_action": proposed_action,
            "gate_decision": decision,
            "actual_action": result.action,
            "post_state": result.post_state,
            "reward_vector": round_floats(result.reward_vector),
            "reward_total": round(reward_total, 8),
            "surprise": round(surprise, 8),
            "dikwp_r": dikwp_r,
            "semantic_mesh": semantic_mesh,
            "quality": quality,
            "model_delta": round_floats(model_delta),
            "logical_time": f"{episode_id}/S{step_no:02d}",
        }
        record = self.ledger.append(payload)
        self.experiences.append(record)
        return record

    def train_environment(self, manifest: EnvironmentManifest, episodes: int, max_steps: int = 12) -> dict[str, Any]:
        env = make_environment(manifest)
        contract = self.contracts[manifest.purpose_contract_id]
        reward_contract = self.reward_contracts[manifest.reward_contract_id]
        agent = self.agents[manifest.environment_id]
        model = self.models[manifest.environment_id]
        successes = 0
        blocked = 0
        returns: list[float] = []
        lengths: list[int] = []

        for ep in range(episodes):
            env.reset()
            episode_id = f"{manifest.environment_id}-EP{ep+1:04d}"
            trace: list[dict[str, Any]] = []
            total = 0.0
            terminal_success = False
            for step_no in range(1, max_steps + 1):
                rec = self._one_step(env, manifest, contract, reward_contract, agent, model, episode_id, step_no)
                trace.append(rec)
                total += rec["reward_total"]
                if rec["post_state"] == "blocked":
                    blocked += 1
                if rec["post_state"] in manifest.terminal_states:
                    terminal_success = rec["post_state"] != "blocked"
                    break
            if terminal_success:
                successes += 1
            self.skill_factory.observe_episode(manifest.environment_id, trace, terminal_success)
            returns.append(total)
            lengths.append(len(trace))
            self.learning_curve.append({
                "environment_id": manifest.environment_id,
                "episode": ep + 1,
                "return": round(total, 8),
                "success": int(terminal_success),
                "steps": len(trace),
                "epsilon": round(agent.epsilon, 6),
            })
            # Reduce exploration but preserve continual discovery.
            agent.epsilon = max(0.07, agent.epsilon * 0.975)

        return {
            "environment_id": manifest.environment_id,
            "episodes": episodes,
            "successes": successes,
            "success_rate": round(successes / max(1, episodes), 6),
            "blocked_terminal_count": blocked,
            "mean_return": round(mean(returns), 6),
            "mean_steps": round(mean(lengths), 6),
            "final_epsilon": round(agent.epsilon, 6),
            "policy": agent.policy(),
        }

    def evaluate_environment(self, manifest: EnvironmentManifest, episodes: int = 20, max_steps: int = 12) -> dict[str, Any]:
        env = make_environment(manifest)
        contract = self.contracts[manifest.purpose_contract_id]
        reward_contract = self.reward_contracts[manifest.reward_contract_id]
        agent = self.agents[manifest.environment_id]
        successes = 0
        unsafe_proposals = 0
        returns = []
        for ep in range(episodes):
            env.reset()
            total = 0.0
            for _ in range(max_steps):
                state = env.state
                action = agent.select_action(state, greedy=True)
                if action in contract.forbidden_actions:
                    unsafe_proposals += 1
                decision = self.gate.decide(
                    manifest, contract, action,
                    human_approved=self._human_approval(manifest.environment_id, state, action),
                    context=self._gate_context(manifest.environment_id, state, action),
                )
                result = env.step(action, decision)
                total += aggregate_reward(result.reward_vector, reward_contract.dimensions, reward_contract.aggregation)
                if result.done:
                    if result.post_state != "blocked":
                        successes += 1
                    break
            returns.append(total)
        return {
            "environment_id": manifest.environment_id,
            "episodes": episodes,
            "success_rate": round(successes / max(1, episodes), 6),
            "unsafe_greedy_proposals": unsafe_proposals,
            "mean_return": round(mean(returns), 6),
        }

    def run(self, episodes: int = 50) -> dict[str, Any]:
        training = [self.train_environment(m, episodes) for m in self.manifests]
        evaluation = [self.evaluate_environment(m, 20) for m in self.manifests]
        skills = self.skill_factory.skills()
        ok, ledger_message = self.ledger.verify()
        world_models = [self.models[m.environment_id].snapshot() for m in self.manifests]
        pack_without_hash = {
            "pack_id": "EPOCH-PACK-2026-07-18-DEMO",
            "agent_id": self.agent_id,
            "purpose_contracts": [self._contract_dict(c) for c in self.contracts.values()],
            "reward_contracts": [self._reward_contract_dict(c) for c in self.reward_contracts.values()],
            "environment_manifests": [self._manifest_dict(m) for m in self.manifests],
            "experiences": self.experiences,
            "world_models": world_models,
            "skills": skills,
            "ledger_head": self.ledger.head,
            "version": "1.0",
        }
        pack_hash = sha256_obj(pack_without_hash)
        pack = {**pack_without_hash, "pack_hash": pack_hash}
        result = {
            "system": "DIKWP-EPOCH OS v1.0",
            "seed": self.seed,
            "agent_id": self.agent_id,
            "training": training,
            "evaluation": evaluation,
            "experience_metrics": summary_metrics(self.experiences),
            "skill_count": len(skills),
            "world_model_count": len(world_models),
            "model_update_count": len(self.model_updates),
            "ledger_valid": ok,
            "ledger_message": ledger_message,
            "ledger_head": self.ledger.head,
            "experience_pack_hash": pack_hash,
            "boundaries": [
                "Synthetic and shadow environments only",
                "Simplified continual Dyna agent; not the full Oak architecture",
                "No proof of phenomenal consciousness",
                "No private chain-of-thought collection",
                "No production action without a separately approved adapter and responsible operator",
            ],
        }
        return {"summary": result, "pack": pack, "world_models": world_models, "skills": skills}


    @staticmethod
    def _semantic_mesh(dikwp_r: dict[str, list[str]]) -> dict[str, Any]:
        nodes = []
        by_kind = {}
        for kind in ["D", "I", "K", "W", "P", "R"]:
            by_kind[kind] = []
            for idx, content in enumerate(dikwp_r[kind]):
                node_id = f"{kind}{idx+1}"
                nodes.append({"node_id": node_id, "kind": kind, "content": content})
                by_kind[kind].append(node_id)
        edges = []
        cycle = [("D", "I", "abstracts"), ("I", "K", "supports"), ("K", "W", "constrains"),
                 ("W", "P", "serves"), ("P", "D", "selects"), ("I", "P", "interprets-for"),
                 ("K", "D", "requests-evidence"), ("W", "I", "reframes")]
        for a, b, relation in cycle:
            if by_kind[a] and by_kind[b]:
                edges.append({"source": by_kind[a][0], "target": by_kind[b][0], "relation": relation})
        for residual in by_kind["R"]:
            for target_kind in ["D", "I", "K", "W", "P"]:
                if by_kind[target_kind]:
                    edges.append({"source": residual, "target": by_kind[target_kind][0], "relation": "keeps-open"})
        return {"nodes": nodes, "edges": edges}

    @staticmethod
    def _contract_dict(c: PurposeContract) -> dict[str, Any]:
        return {
            "contract_id": c.contract_id, "purpose": c.purpose, "principal": c.principal,
            "beneficiaries": list(c.beneficiaries), "allowed_actions": list(c.allowed_actions),
            "forbidden_actions": list(c.forbidden_actions),
            "human_approval_required": list(c.human_approval_required), "risk_budget": c.risk_budget,
            "reward_contract_id": c.reward_contract_id, "kill_conditions": list(c.kill_conditions),
            "valid_until": c.valid_until, "version": c.version,
        }

    @staticmethod
    def _reward_contract_dict(c: RewardContract) -> dict[str, Any]:
        return {
            "reward_contract_id": c.reward_contract_id, "dimensions": c.dimensions,
            "aggregation": c.aggregation, "anti_gaming_rules": list(c.anti_gaming_rules),
            "human_override": c.human_override, "version": c.version,
        }

    @staticmethod
    def _manifest_dict(m: EnvironmentManifest) -> dict[str, Any]:
        return {
            "environment_id": m.environment_id, "name": m.name, "description": m.description,
            "environment_class": m.environment_class, "states": list(m.states), "actions": list(m.actions),
            "action_risk": m.action_risk, "terminal_states": list(m.terminal_states),
            "purpose_contract_id": m.purpose_contract_id, "reward_contract_id": m.reward_contract_id,
            "reset_policy": m.reset_policy, "version": m.version,
        }

    def write_outputs(self, outdir: str | Path, episodes: int = 50) -> dict[str, Any]:
        out = Path(outdir)
        out.mkdir(parents=True, exist_ok=True)
        result = self.run(episodes=episodes)
        self.ledger.write_jsonl(out / "experience_ledger.jsonl")
        dump_json(out / "experience_pack.json", result["pack"])
        dump_json(out / "summary.json", result["summary"])
        dump_json(out / "world_model.json", result["world_models"])
        dump_json(out / "skills.json", result["skills"])
        dump_json(out / "model_updates.json", self.model_updates)
        with (out / "learning_curve.csv").open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["environment_id", "episode", "return", "success", "steps", "epsilon"])
            writer.writeheader()
            writer.writerows(self.learning_curve)
        release = {
            "release_id": "PER-2026-07-18-DEMO",
            "pack_hashes": [result["pack"]["pack_hash"]],
            "summary": result["summary"],
            "known_failures": result["summary"]["boundaries"],
            "governance_decision": "DRAFT",
            "version": "1.0",
        }
        dump_json(out / "public_experience_release.json", release)
        return result
