from __future__ import annotations

from statistics import mean
from typing import Any


def aggregate_reward(vector: dict[str, float], weights: dict[str, float], aggregation: str) -> float:
    weighted = sum(float(vector.get(k, 0.0)) * float(w) for k, w in weights.items())
    if aggregation == "constrained":
        # Safety and human-value violations cannot be compensated by task progress.
        if vector.get("safety", 0.0) < -0.05 or vector.get("human_value", 0.0) < -0.10:
            weighted -= 1.0
    return weighted


def experience_quality(*, gate: str, success: bool, surprise: float, reward_vector: dict[str, float], model_confidence: float, replayable: bool = True) -> dict[str, float]:
    groundedness = 1.0 if reward_vector else 0.0
    causal_fit = max(0.0, min(1.0, 1.0 - surprise))
    novelty = max(0.0, min(1.0, surprise))
    safety = 1.0 if gate in {"ALLOW", "BLOCK", "KILL"} else 0.75
    semantic = 1.0
    transfer = 0.70 if success else 0.35
    longitudinal = 0.65 + 0.25 * model_confidence
    return {
        "groundedness": round(groundedness, 6), "causal_fit": round(causal_fit, 6),
        "novelty": round(novelty, 6), "replayability": 1.0 if replayable else 0.0,
        "safety": round(safety, 6), "semantic_completeness": semantic,
        "transferability": round(transfer, 6), "longitudinal_value": round(min(1.0, longitudinal), 6),
    }


def summary_metrics(experiences: list[dict[str, Any]]) -> dict[str, Any]:
    if not experiences:
        return {}
    decisions: dict[str, int] = {}
    for x in experiences:
        d = x["gate_decision"]["decision"]
        decisions[d] = decisions.get(d, 0) + 1
    quality_keys = sorted(experiences[0]["quality"].keys())
    quality = {k: round(mean(x["quality"][k] for x in experiences), 6) for k in quality_keys}
    return {
        "experience_count": len(experiences),
        "gate_decisions": decisions,
        "mean_reward": round(mean(x["reward_total"] for x in experiences), 6),
        "mean_surprise": round(mean(x["surprise"] for x in experiences), 6),
        "quality": quality,
    }
