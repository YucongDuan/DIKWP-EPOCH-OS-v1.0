from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class PurposeContract:
    contract_id: str
    purpose: str
    principal: str
    beneficiaries: tuple[str, ...]
    allowed_actions: tuple[str, ...]
    forbidden_actions: tuple[str, ...]
    human_approval_required: tuple[str, ...]
    risk_budget: float
    reward_contract_id: str
    kill_conditions: tuple[str, ...]
    valid_until: str
    version: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "PurposeContract":
        return cls(
            contract_id=d["contract_id"], purpose=d["purpose"], principal=d["principal"],
            beneficiaries=tuple(d.get("beneficiaries", [])),
            allowed_actions=tuple(d.get("allowed_actions", [])),
            forbidden_actions=tuple(d.get("forbidden_actions", [])),
            human_approval_required=tuple(d.get("human_approval_required", [])),
            risk_budget=float(d["risk_budget"]), reward_contract_id=d["reward_contract_id"],
            kill_conditions=tuple(d.get("kill_conditions", [])), valid_until=d.get("valid_until", ""),
            version=d.get("version", "1.0"),
        )


@dataclass(frozen=True)
class RewardContract:
    reward_contract_id: str
    dimensions: dict[str, float]
    aggregation: str
    anti_gaming_rules: tuple[str, ...]
    human_override: bool
    version: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "RewardContract":
        return cls(
            reward_contract_id=d["reward_contract_id"],
            dimensions={k: float(v) for k, v in d["dimensions"].items()},
            aggregation=d["aggregation"], anti_gaming_rules=tuple(d.get("anti_gaming_rules", [])),
            human_override=bool(d.get("human_override", False)), version=d.get("version", "1.0"),
        )


@dataclass(frozen=True)
class EnvironmentManifest:
    environment_id: str
    name: str
    description: str
    environment_class: str
    states: tuple[str, ...]
    actions: tuple[str, ...]
    action_risk: dict[str, float]
    terminal_states: tuple[str, ...]
    purpose_contract_id: str
    reward_contract_id: str
    reset_policy: str
    version: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "EnvironmentManifest":
        return cls(
            environment_id=d["environment_id"], name=d["name"], description=d.get("description", ""),
            environment_class=d["environment_class"], states=tuple(d["states"]), actions=tuple(d["actions"]),
            action_risk={k: float(v) for k, v in d.get("action_risk", {}).items()},
            terminal_states=tuple(d["terminal_states"]), purpose_contract_id=d["purpose_contract_id"],
            reward_contract_id=d["reward_contract_id"], reset_policy=d.get("reset_policy", ""),
            version=d.get("version", "1.0"),
        )


@dataclass
class StepResult:
    pre_state: str
    action: str | None
    post_state: str
    reward_vector: dict[str, float]
    done: bool
    observation: dict[str, Any]
    consequence: dict[str, Any]
    success: bool
    info: dict[str, Any] = field(default_factory=dict)
