# Changelog

## v1.0.0 — 2026-07-18

- Added the ExperienceCell v1 public object.
- Added three deterministic synthetic/shadow environments.
- Added Purpose Contract, Grounded Reward Contract, and five-level action gate.
- Added DIKWP-R semantic mesh compilation.
- Added tabular world models, TD learning, Dyna planning, adaptive state-action step sizes, and SkillOption discovery.
- Added append-only experience ledger, ExperiencePack, ReplicationReceipt, and PublicExperienceRelease.
- Added 11 JSON Schemas, 16 automated tests, offline dashboard, CI/Release/Pages workflows, and Chinese final Word specification.
- Declared explicit scientific, ethical, and field-deployment boundaries.
